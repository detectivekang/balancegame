import React, { useState } from "react";
import { HashRouter, Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import SignupModal from "./components/SignupModal";
import Home from "./pages/Home";
import Submit from "./pages/Submit";
import Admin from "./pages/Admin";
import HallOfFame from "./pages/HallOfFame";
import { useDevice, needsSignup } from "./hooks/useDevice";
import { PlayerProvider } from "./hooks/usePlayer";
import "./App.css";

// GitHub Pages는 클라이언트 라우팅 새로고침 시 404가 나기 쉬워서
// BrowserRouter 대신 HashRouter(#/admin 형태)를 사용합니다.
export default function App() {
  const deviceId = useDevice();
  const [signedUp, setSignedUp] = useState(!needsSignup());

  if (!signedUp) {
    return <SignupModal deviceId={deviceId} onDone={() => setSignedUp(true)} />;
  }

  return (
    <PlayerProvider>
      <HashRouter>
        <Header />
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/submit" element={<Submit />} />
            <Route path="/hall-of-fame" element={<HallOfFame />} />
            <Route path="/admin" element={<Admin />} />
          </Routes>
        </main>
      </HashRouter>
    </PlayerProvider>
  );
}
