import React, { useEffect, useState } from "react";
import {
  collection,
  getCountFromServer,
  query,
  where,
} from "firebase/firestore";
import { db } from "../firebase";
import { AGE_BUCKETS, GENDERS } from "../data/demographics";

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [demographics, setDemographics] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const today = todayStr();

        const [totalUsers, todaySignups, dau, totalQuestions, pendingQuestions] =
          await Promise.all([
            getCountFromServer(collection(db, "users")),
            getCountFromServer(
              query(collection(db, "users"), where("firstSeenDate", "==", today))
            ),
            getCountFromServer(
              query(collection(db, "dailyActive"), where("date", "==", today))
            ),
            getCountFromServer(
              query(collection(db, "questions"), where("status", "==", "approved"))
            ),
            getCountFromServer(
              query(collection(db, "questions"), where("status", "==", "pending"))
            ),
          ]);

        setStats({
          totalUsers: totalUsers.data().count,
          todaySignups: todaySignups.data().count,
          dau: dau.data().count,
          totalQuestions: totalQuestions.data().count,
          pendingQuestions: pendingQuestions.data().count,
        });

        const genderCounts = await Promise.all(
          GENDERS.map((g) =>
            getCountFromServer(query(collection(db, "users"), where("gender", "==", g)))
          )
        );
        const ageCounts = await Promise.all(
          AGE_BUCKETS.map((b) =>
            getCountFromServer(
              query(
                collection(db, "users"),
                where("age", ">=", b.min),
                where("age", "<", b.max)
              )
            )
          )
        );

        setDemographics({
          gender: GENDERS.map((g, i) => ({ label: g, count: genderCounts[i].data().count })),
          age: AGE_BUCKETS.map((b, i) => ({ label: b.label, count: ageCounts[i].data().count })),
        });
      } catch (err) {
        console.error("통계 로딩 실패:", err);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  if (loading) return <p>통계를 불러오는 중...</p>;
  if (!stats) return <p>통계를 불러오지 못했습니다.</p>;

  const cards = [
    { label: "누적 유저 수", value: stats.totalUsers },
    { label: "오늘 가입자", value: stats.todaySignups },
    { label: "일일 활성 사용자(DAU)", value: stats.dau },
    { label: "등록된 총 문제 수", value: stats.totalQuestions },
    { label: "승인 대기 문제", value: stats.pendingQuestions },
  ];

  const maxAge = demographics ? Math.max(1, ...demographics.age.map((a) => a.count)) : 1;
  const maxGender = demographics ? Math.max(1, ...demographics.gender.map((g) => g.count)) : 1;

  return (
    <div>
      <div className="admin-dashboard">
        {cards.map((c) => (
          <div key={c.label} className="admin-dashboard__card">
            <div className="admin-dashboard__value">{c.value.toLocaleString()}</div>
            <div className="admin-dashboard__label">{c.label}</div>
          </div>
        ))}
      </div>

      {demographics && (
        <div className="admin-demographics">
          <h4>성별 분포</h4>
          <div className="admin-demographics__bars">
            {demographics.gender.map((g) => (
              <div key={g.label} className="admin-demographics__row">
                <span className="admin-demographics__label">{g.label}</span>
                <div className="admin-demographics__track">
                  <div
                    className="admin-demographics__fill"
                    style={{ width: `${(g.count / maxGender) * 100}%` }}
                  />
                </div>
                <span className="admin-demographics__count">{g.count}</span>
              </div>
            ))}
          </div>

          <h4>연령대 분포</h4>
          <div className="admin-demographics__bars">
            {demographics.age.map((a) => (
              <div key={a.label} className="admin-demographics__row">
                <span className="admin-demographics__label">{a.label}</span>
                <div className="admin-demographics__track">
                  <div
                    className="admin-demographics__fill"
                    style={{ width: `${(a.count / maxAge) * 100}%` }}
                  />
                </div>
                <span className="admin-demographics__count">{a.count}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
