import React, { useEffect, useState } from "react";
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  query,
  serverTimestamp,
  updateDoc,
  where,
} from "firebase/firestore";
import { db } from "../firebase";

const APPROVAL_BONUS_XP = 5;

export default function AdminApprovals() {
  const [pending, setPending] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, "questions"), where("status", "==", "pending"));
    const unsub = onSnapshot(q, (snap) => {
      setPending(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      setLoading(false);
    });
    return unsub;
  }, []);

  const approve = async (q) => {
    await updateDoc(doc(db, "questions", q.id), { status: "approved" });

    // 유저가 직접 등록한 문제라면 제출자에게 보너스 XP 지급
    if (q.submitterId) {
      try {
        const userRef = doc(db, "users", q.submitterId);
        const snap = await getDoc(userRef);
        if (snap.exists()) {
          const currentXp = snap.data().xp || 0;
          await updateDoc(userRef, { xp: currentXp + APPROVAL_BONUS_XP });
          await addDoc(collection(db, "xpEvents"), {
            deviceId: q.submitterId,
            amount: APPROVAL_BONUS_XP,
            type: "approval",
            category: q.category,
            createdAt: serverTimestamp(),
          });
        }
      } catch (err) {
        console.error("승인 보너스 XP 지급 실패:", err);
      }
    }
  };

  const reject = async (id) => {
    await deleteDoc(doc(db, "questions", id));
  };

  if (loading) return <p>불러오는 중...</p>;
  if (pending.length === 0) return <p>승인 대기 중인 문제가 없습니다.</p>;

  return (
    <div className="admin-approvals">
      {pending.map((q) => (
        <div key={q.id} className="admin-approvals__item">
          <div className="admin-approvals__category">{q.category}</div>
          <div className="admin-approvals__question">{q.question}</div>
          <div className="admin-approvals__options">
            <span>{q.optionA}</span>
            <span>vs</span>
            <span>{q.optionB}</span>
          </div>
          <div className="admin-approvals__actions">
            <button onClick={() => approve(q)}>승인 (+{APPROVAL_BONUS_XP} XP)</button>
            <button onClick={() => reject(q.id)} className="is-danger">
              반려
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
