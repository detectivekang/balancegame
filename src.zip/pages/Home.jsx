import React, { useEffect, useState, useMemo, useRef } from "react";
import { collection, onSnapshot, query, where } from "firebase/firestore";
import { db } from "../firebase";
import { CATEGORIES } from "../data/categories";
import CategoryGrid from "../components/CategoryGrid";
import BalanceCard from "../components/BalanceCard";
import PlayerStatusBar from "../components/PlayerStatusBar";
import EnergyEmpty from "../components/EnergyEmpty";
import { usePlayer } from "../hooks/usePlayer";

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export default function Home() {
  const player = usePlayer();
  const [questions, setQuestions] = useState([]);
  const [category, setCategory] = useState(null); // null = 카테고리 선택 화면
  const [queue, setQueue] = useState([]); // 랜덤 순서로 섞인 현재 카테고리의 문제 큐
  const [loading, setLoading] = useState(true);
  const seenIds = useRef(new Set());

  useEffect(() => {
    const q = query(collection(db, "questions"), where("status", "==", "approved"));
    const unsub = onSnapshot(
      q,
      (snap) => {
        setQuestions(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
        setLoading(false);
      },
      (err) => {
        console.error("문제 목록 로딩 실패:", err);
        setLoading(false);
      }
    );
    return unsub;
  }, []);

  const counts = useMemo(() => {
    const map = {};
    questions.forEach((q) => {
      map[q.category] = (map[q.category] || 0) + 1;
    });
    return map;
  }, [questions]);

  const current = queue[0] || null;

  const handleSelectCategory = (c) => {
    const pool = questions.filter((q) => q.category === c);
    seenIds.current = new Set();
    setCategory(c);
    setQueue(shuffle(pool));
  };

  const handleNext = () => {
    setQueue((prev) => {
      const [done, ...rest] = prev;
      if (done) seenIds.current.add(done.id);

      if (rest.length > 0) return rest;

      // 다 풀었으면 같은 카테고리 문제를 다시 랜덤 순서로 셔플해서 계속 진행
      const pool = questions.filter((q) => q.category === category);
      seenIds.current = new Set();
      return shuffle(pool);
    });
  };

  if (loading) {
    return <p className="empty-state">문제를 불러오는 중...</p>;
  }

  if (!category) {
    return (
      <div className="page page--home">
        <PlayerStatusBar />
        <CategoryGrid categories={CATEGORIES} counts={counts} onSelect={handleSelectCategory} />
      </div>
    );
  }

  const energyEmpty = player && player.currentEnergy <= 0;

  return (
    <div className="page page--home">
      <button className="back-link" onClick={() => setCategory(null)}>
        ← 카테고리 다시 선택
      </button>

      <PlayerStatusBar />

      {energyEmpty && <EnergyEmpty />}

      {!energyEmpty && !current && (
        <p className="empty-state">
          아직 이 카테고리에 등록된 문제가 없어요. 직접 등록해보시겠어요?
        </p>
      )}

      {!energyEmpty && current && (
        <BalanceCard key={current.id} q={current} onNext={handleNext} />
      )}
    </div>
  );
}
