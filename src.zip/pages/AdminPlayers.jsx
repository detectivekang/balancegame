import React, { useState } from "react";
import {
  collection,
  getCountFromServer,
  getDocs,
  limit,
  orderBy,
  query,
  startAfter,
} from "firebase/firestore";
import { db } from "../firebase";
import { levelForXp, tierForLevel } from "../utils/levels";

const PAGE_SIZE = 20;

export default function AdminPlayers() {
  const [players, setPlayers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [lastDoc, setLastDoc] = useState(null);
  const [hasMore, setHasMore] = useState(true);

  const loadPage = async (after) => {
    const q = after
      ? query(
          collection(db, "users"),
          orderBy("createdAt", "desc"),
          startAfter(after),
          limit(PAGE_SIZE)
        )
      : query(collection(db, "users"), orderBy("createdAt", "desc"), limit(PAGE_SIZE));
    const snap = await getDocs(q);

    const withCounts = await Promise.all(
      snap.docs.map(async (d) => {
        const data = d.data();
        let voteCount = 0;
        try {
          const countSnap = await getCountFromServer(collection(db, "users", d.id, "votes"));
          voteCount = countSnap.data().count;
        } catch (err) {
          console.error("투표수 조회 실패:", err);
        }
        const xp = data.xp || 0;
        const level = levelForXp(xp);
        return {
          id: d.id,
          nickname: data.nickname || "(닉네임 없음)",
          age: data.age,
          gender: data.gender,
          firstSeenDate: data.firstSeenDate,
          voteCount,
          xp,
          level,
          tier: tierForLevel(level),
        };
      })
    );

    setPlayers((prev) => (after ? [...prev, ...withCounts] : withCounts));
    setLastDoc(snap.docs[snap.docs.length - 1] || null);
    setHasMore(snap.docs.length === PAGE_SIZE);
  };

  React.useEffect(() => {
    loadPage(null).finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleLoadMore = async () => {
    setLoadingMore(true);
    await loadPage(lastDoc);
    setLoadingMore(false);
  };

  if (loading) return <p>불러오는 중...</p>;
  if (players.length === 0) return <p>아직 가입한 플레이어가 없습니다.</p>;

  return (
    <div className="admin-players">
      <div className="admin-players__table-wrap">
        <table className="admin-players__table">
          <thead>
            <tr>
              <th>닉네임</th>
              <th>나이</th>
              <th>성별</th>
              <th>레벨/티어</th>
              <th>XP</th>
              <th>가입일</th>
              <th>참여 문제 수</th>
            </tr>
          </thead>
          <tbody>
            {players.map((p) => (
              <tr key={p.id}>
                <td>{p.nickname}</td>
                <td>{p.age}</td>
                <td>{p.gender}</td>
                <td>
                  Lv.{p.level} · {p.tier.label}
                </td>
                <td>{p.xp.toLocaleString()}</td>
                <td>{p.firstSeenDate}</td>
                <td>{p.voteCount.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {hasMore && (
        <button
          className="admin-players__more"
          onClick={handleLoadMore}
          disabled={loadingMore}
        >
          {loadingMore ? "불러오는 중..." : "더 보기"}
        </button>
      )}
    </div>
  );
}
