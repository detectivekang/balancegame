import React, { useState } from "react";
import { addDoc, collection, doc, increment, serverTimestamp, setDoc, updateDoc } from "firebase/firestore";
import { db } from "../firebase";
import { hasVoted, markVoted, getVotedChoice, getDeviceId } from "../hooks/useDevice";
import { usePlayer } from "../hooks/usePlayer";

export default function BalanceCard({ q, onNext }) {
  const player = usePlayer();
  const [choice, setChoice] = useState(() => getVotedChoice(q.id));
  const voted = hasVoted(q.id) || Boolean(choice);

  const totalVotes = (q.votesA || 0) + (q.votesB || 0);
  const percentA = totalVotes > 0 ? Math.round(((q.votesA || 0) / totalVotes) * 100) : 50;
  const percentB = 100 - percentA;

  const vote = async (side) => {
    if (voted) return;
    if (player && player.currentEnergy <= 0) return;

    setChoice(side); // 낙관적 업데이트
    markVoted(q.id, side);
    try {
      const deviceId = getDeviceId();
      await Promise.all([
        updateDoc(doc(db, "questions", q.id), {
          [side === "A" ? "votesA" : "votesB"]: increment(1),
        }),
        // 플레이어별 통계(관리자 페이지)를 위한 기기별 투표 기록
        setDoc(doc(db, "users", deviceId, "votes", q.id), {
          questionId: q.id,
          category: q.category,
          choice: side,
          createdAt: serverTimestamp(),
        }),
        // 명예의 전당(주간/월간 랭킹) 집계용 경험치 로그
        addDoc(collection(db, "xpEvents"), {
          deviceId,
          amount: 1,
          type: "vote",
          category: q.category,
          createdAt: serverTimestamp(),
        }),
      ]);
      if (player) await player.spendEnergyAndGainXp();
    } catch (err) {
      console.error("투표 반영 실패:", err);
    }
  };

  return (
    <div className="balance-card">
      <div className="balance-card__category">{q.category}</div>
      <h3 className="balance-card__question">{q.question}</h3>

      {!voted && (
        <div className="balance-card__options">
          <button className="balance-card__option opt-a" onClick={() => vote("A")}>
            {q.optionA}
          </button>
          <div className="balance-card__vs">VS</div>
          <button className="balance-card__option opt-b" onClick={() => vote("B")}>
            {q.optionB}
          </button>
        </div>
      )}

      {voted && (
        <div className="balance-result">
          <div className="balance-result__row">
            <div className="balance-result__labels">
              <span>{q.optionA}</span>
              <span className="balance-result__percent">{percentA}%</span>
            </div>
            <div className="balance-result__track">
              <div
                className={`balance-result__fill opt-a ${choice === "A" ? "is-my-choice" : ""}`}
                style={{ width: `${percentA}%` }}
              />
            </div>
          </div>

          <div className="balance-result__row">
            <div className="balance-result__labels">
              <span>{q.optionB}</span>
              <span className="balance-result__percent">{percentB}%</span>
            </div>
            <div className="balance-result__track">
              <div
                className={`balance-result__fill opt-b ${choice === "B" ? "is-my-choice" : ""}`}
                style={{ width: `${percentB}%` }}
              />
            </div>
          </div>

          <p className="balance-result__meta">
            지금까지 <b>{totalVotes.toLocaleString()}명</b> 참여했어요 (+1 XP)
          </p>
        </div>
      )}

      <button className="balance-card__next" onClick={onNext}>
        다음 문제 →
      </button>
    </div>
  );
}
